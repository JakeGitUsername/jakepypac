# jakepypac
This library was created to provide different types of functions to be applied in solving particular problems in Data Science and Programming contexts.

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/JakeGitUsername/jakepypac.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/JakeGitUsername/jakepypac.git`
